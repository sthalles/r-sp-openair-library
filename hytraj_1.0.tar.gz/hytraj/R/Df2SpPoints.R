Df2SpPoints <-
function(traj, crs = NA)
{
  # This function converts an object of class data frame, calculated by the 
  # function ProcTraj, into an object of class SpatialPoints.
  #
  # Args:
  #   df: Data Frame Object created by the function ProcTraj.
  #   crs: Object of class."CRS"; holding a valid proj4 string.
  #
  # Results:
  #   An SpatialPoints object  
  
  # get the coordinates out of the data.frame
  cc <- traj[7:8]
  
  # reverse the order of the columns from [Lat Long] to [Long Lat]
  cc <- cc[,c(2,1)]
  
  # get all the data (except) the coordinates
  df <- traj[-7:-8]
  
  # create a SpatialPointsDataFrame object
  sp.lines.df <- SpatialPointsDataFrame(coords = cc, data = df, proj4string = crs)
  
  sp.lines.df
}
